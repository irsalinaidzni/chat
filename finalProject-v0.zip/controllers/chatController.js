const Chat = require('../models/Chat')

module.exports = {
  createChat: (req,res) => {

  }
}