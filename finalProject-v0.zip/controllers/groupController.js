const Group = require('../models/Group')

module.exports = {
  createGroup: (req,res) => {

  },

  inviteFriend: (req,res) => {

  }
}