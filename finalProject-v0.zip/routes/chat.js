const express = require('express')
const router = express.Router()
const chatController = require('../controllers/chatController')

router
      // .get('/', chatController.)
      // .post('/', chatController.)
      // .put('/', chatController.)

module.exports = router