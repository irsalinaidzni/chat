const express = require('express')
const router = express.Router()
const groupController = require('../controllers/userController')

router
      // .get('/', groupController.)
      // .post('/', groupController.)
      // .put('/', groupController.)

module.exports = router